# badmagic_graphql
 graphql lambda function
