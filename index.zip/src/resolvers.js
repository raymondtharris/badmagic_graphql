const { gql } = require('apollo-server');

const bmdb = new AWS.DynamoDB({ apiVersion:  '2012-08-10'});
const documentClient = new AWS.DynamoDB.DocumentClient({region: "us-east-1"});

const resolvers = {
    Query : {
        newsletterUser : (_,{emailAddress}, {datasources}) => {
            
        }
    },
};


module.exports = resolvers;